import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

@SuppressWarnings({ "unused", "unused", "unused", "unused" })
public class InMemoryJoin {
	
	public static class Map	extends Mapper<LongWritable, Text, Text, Text>{
		
		HashMap<String,String> friendsMap = new HashMap<String,String>();
		HashMap<String,User> userMap = new HashMap<String,User>();
		private Text outputKey = new Text();
		private Text outputValue = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			
			String[] mydata = value.toString().trim().split(","); //gets the two user ids from input file
			ArrayList<String> friendLists = new ArrayList<>();
			String user1Friends[] = friendsMap.get(mydata[0]).split(","); // get the friends of user 1
			String user2Friends[] = friendsMap.get(mydata[1]).split(","); // get the friends of user 2
			int length1 = user1Friends.length;
			int length2 = user2Friends.length;
			for(int j=0;j<length1;j++) {
				for(int k=0;k<length2;k++) {
					if(user1Friends[j].equals(user2Friends[k])) {
						friendLists.add(user1Friends[j]); // add the mutual friends to the list
					}
				}
			}
			String out = "[ ";
			for(String userId : friendLists) {
				User details = userMap.get(userId);
				out+=details.getFirstName()+" : "+details.getCity()+" , ";
			}
			out+=" ]";
			outputKey = value;
			outputValue.set(out);
			
			context.write(outputKey, outputValue);

		}
		
		
		@Override
		protected void setup(Context context)
				throws IOException, InterruptedException {
			super.setup(context);
			//read data to memory on the mapper.
			Configuration conf = context.getConfiguration();
			//String myfilePath = conf.get("/zxw151030/input/2/userdata.txt");
			//e.g /user/hue/input/
			Path part=new Path("/user/navya/input/soc-LiveJournal1Adj.txt");//Location of file in HDFS
			
			
			FileSystem fs = FileSystem.get(conf);
			FileStatus[] fss = fs.listStatus(part);
		    for (FileStatus status : fss) {
		        Path pt = status.getPath();
		        
		        BufferedReader br=new BufferedReader(new InputStreamReader(fs.open(pt)));
		        String line;
		        line=br.readLine();
		        while (line != null){
		        	String[] arr=line.split("\t");
		        	//put (word, wordid) in the HashMap variable
		        	if(arr.length<2)
		        		friendsMap.put(arr[0],"");
		        	else
		        		friendsMap.put(arr[0], arr[1]);
		        	line=br.readLine();
		        }
		    }
		    part = new Path("/user/navya/input/userdata.txt");
		    fs = FileSystem.get(conf);
			fss = fs.listStatus(part);
			String userId = "";
		    for (FileStatus status : fss) {
		        Path pt = status.getPath();
		        
		        BufferedReader br=new BufferedReader(new InputStreamReader(fs.open(pt)));
		        String line;
		        line=br.readLine();
		        while (line != null){
		        	String[] arr=line.split(",");
		        	//put (word, wordid) in the HashMap variable
		        	userId= arr[0];
		        	User user = new User();
		        	user.setFirstName(arr[1]);
		        	user.setLastName(arr[2]);
		        	user.setStreetAddress(arr[3]);
		        	user.setCity(arr[4]);
		        	user.setState(arr[5]);
		        	user.setCountry(arr[6]);
		        	user.setZipcode(arr[7]);
		        	user.setUnique(arr[8]);
		        	user.setDate(arr[9]);
		        	userMap.put(arr[0], user);
		        	line=br.readLine();
		        }
		    }
		}
	}
	
	
	

	public static class Reduce	extends Reducer<Text,Text ,Text,Text> {

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			for (Text val : values) {
				context.write(key, val); // create a pair <keyword, number of occurences>
			}
			
		}
	}


	// Driver program
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		// get all args
		if (otherArgs.length != 4) {
			System.err.println("Usage: InMemoryJoin <in> <path to friendslist file> <path to userdata file><out> ");
			System.exit(2);
		}
		
		//conf.set("FRIENDLIST",otherArgs[1]);
		//conf.set("FRIENDLIST","/home/navya/Documents/soc-LiveJournal1Adj.txt");
		//conf.set("USERDATA","/home/navya/Documents/userdata.txt");
		// create a job with name "wordcount"
		@SuppressWarnings("deprecation")
		Job job = new Job(conf, "wordid");
		job.setJarByClass(InMemoryJoin.class);
		job.setMapperClass(Map.class);
		job.setReducerClass(Reduce.class);


		// uncomment the following line to add the Combiner job.setCombinerClass(Reduce.class);


		
		job.setOutputKeyClass(Text.class);
		// set output value type
		job.setOutputValueClass(Text.class);
		//set the HDFS path of the input data
		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		// set the HDFS path for the output
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[3]));
		//Wait till job completion
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
	
}
