import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;


import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;

@SuppressWarnings("unused")
public class AverageAge{
	public static class Map	extends Mapper<LongWritable, Text, Text, Text>{
		
		private Text outputKey = new Text();
		private Text outputValue = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			
			String[] mydata = value.toString().trim().split("\t"); //gets the two user ids from input file
			
			
			if(mydata.length==2) {
				outputKey.set(mydata[0]);
				outputValue.set(mydata[1]);
			
				context.write(outputKey, outputValue);
			}

		}
		
		

	}
	
	
	

	public static class Reduce	extends Reducer<Text,Text ,LongWritable,Text> {
		
		HashMap<String,User> userMap = new HashMap<String,User>();
		private LongWritable outputKey = new LongWritable();
		private Text outputValue = new Text();
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			int AvgAge = Integer.MAX_VALUE;
		
				for (Text friends : values) {
				
					String friendArr[] = friends.toString().trim().split(",");
					int sum = 0, count=0;
					for (String friend : friendArr) {
						User friendDetails = userMap.get(friend);
						//System.out.println(friendDetails.getDate()+"  "+setAge(friendDetails.getDate()));
						setAge(friendDetails.getDate());
						int age = friendDetails.getAge();
						sum = sum+age;
						count++;
					}
					AvgAge = sum/count;
				
					User user = userMap.get(key.toString());
					String userAdd = user.getStreetAddress()+","+user.getCity()+","+user.getState();
					String out = AvgAge+"";
					outputKey.set(AvgAge);
					outputValue.set(key.toString()+","+userAdd);
					context.write(outputKey, outputValue); // create a pair <keyword, number of occurences>
				}
			
			
		}
		public int setAge(String date) {
			
			return 2018-Integer.parseInt(date);
			
		}
		@Override
		protected void setup(Context context) throws IOException, InterruptedException {
			super.setup(context);
			//read data to memory on the mapper.
			Configuration conf = context.getConfiguration();

			System.out.println("Userdata string : "+conf.get("USERDATA"));
			//Path part = new Path(conf.get("USERDATA"));
		    Path part = new Path("/user/navya/input/userdata.txt");
		    FileSystem fs = FileSystem.get(conf);
			FileStatus []fss = fs.listStatus(part);
			String userId = "";
		    for (FileStatus status : fss) {
		        Path pt = status.getPath();
		        
		        BufferedReader br=new BufferedReader(new InputStreamReader(fs.open(pt)));
		        String line;
		        line=br.readLine();
		        while (line != null){
		        	String[] arr=line.split(",");
		        	//put (word, wordid) in the HashMap variable
		        	userId= arr[0];
		        	User user = new User();
		        	user.setFirstName(arr[1]);
		        	user.setLastName(arr[2]);
		        	user.setStreetAddress(arr[3]);
		        	user.setCity(arr[4]);
		        	user.setState(arr[5]);
		        	user.setCountry(arr[6]);
		        	user.setZipcode(arr[7]);
		        	user.setUnique(arr[8]);
		        	int len = arr[9].trim().length();
		        	user.setDate(arr[9].trim().substring(len-4, len));
		        	user.setAge();
		        	userMap.put(arr[0], user);
		        	line=br.readLine();
		        }
		    }
		}
	}
	
	public static class Map2 extends Mapper<LongWritable, Text, LongWritable, Text>{
		private LongWritable outputKey = new LongWritable();
		private Text outputValue = new Text();
		
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		
			String mydata[] = value.toString().trim().split("\t");
			int age = Integer.parseInt(mydata[0].trim());
			outputKey.set(age);
			outputValue.set(mydata[1]);
			context.write(outputKey, outputValue);
		}
	}
	public static class Reduce2	extends Reducer<LongWritable, Text ,Text, LongWritable> {
		private Text outputKey =new Text();
		private LongWritable outputValue = new LongWritable();
		private int idx = 0;
		public void reduce(LongWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		
			for(Text value : values) {
				
				if(idx <10) {
					idx++;
					outputKey = value;
					outputValue = key;
					context.write(outputKey, outputValue);
				}
			}
		}
	}
	// Driver program
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        String inputPath = otherArgs[0];
        String outputPath = otherArgs[2];
        String tempPath = otherArgs[1];
        String finalOutputPath = otherArgs[3];
        System.out.println(otherArgs.length);
		// get all args
		if (otherArgs.length != 4) {
			System.err.println("Usage: InMemoryJoin <in> <out> <path to friendslist file> <path to userdata file>");
			System.exit(2);
		}


        //First Job

            Job job = new Job(conf, "WordCount");

            conf.set("USERDATA", otherArgs[1]);
            System.out.println("conf : "+conf.get("USERDATA"));
            job.setJarByClass(AverageAge.class);
            job.setMapperClass(AverageAge.Map.class);
            job.setReducerClass(AverageAge.Reduce.class);
            
            //set job1's mapper output key type
            job.setMapOutputKeyClass(Text.class);
            //set job1's mapper output value type
            job.setMapOutputValueClass(Text.class);
            
            // set job1;s output key type
            job.setOutputKeyClass(Text.class);
            // set job1's output value type
            job.setOutputValueClass(Text.class);
            //set job1's input HDFS path
            FileInputFormat.addInputPath(job, new Path(inputPath));
            //job1's output path
            FileOutputFormat.setOutputPath(job, new Path(outputPath));

        if(job.waitForCompletion(true))
        //Second Job
        {
        	System.out.println("***********************************************************************************************************");
        	System.out.println("************************************************ START OF 2ND JOB *****************************************");
        	System.out.println("***********************************************************************************************************");
            conf = new Configuration();
            Job job2 = new Job(conf, "TopCount");

            job2.setJarByClass(AverageAge.class);
            job2.setMapperClass(AverageAge.Map2.class);
            job2.setReducerClass(AverageAge.Reduce2.class);
            
            //set job2's mapper output key type
            job2.setMapOutputKeyClass(LongWritable.class);
            //set job2's mapper output value type
            job2.setMapOutputValueClass(Text.class);
            
            //set job2's output key type
            job2.setOutputKeyClass(Text.class);
            //set job2's output value type
            job2.setOutputValueClass(LongWritable.class);

            //job2.setInputFormatClass(KeyValueTextInputFormat.class);
            
            //hadoop by default sorts the output of map by key in ascending order, set it to decreasing order
            job2.setSortComparatorClass(LongWritable.DecreasingComparator.class);

            job2.setNumReduceTasks(1);
            //job2's input is job1's output
            FileInputFormat.addInputPath(job2, new Path(outputPath));
            //set job2's output path
            FileOutputFormat.setOutputPath(job2, new Path(finalOutputPath));

            System.exit(job2.waitForCompletion(true) ? 0 : 1);
        }
	}
}

