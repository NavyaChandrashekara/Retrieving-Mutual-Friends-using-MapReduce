import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

@SuppressWarnings("unused")
public class Top10MutualFriends {
	public static class MutualMap extends Mapper<LongWritable, Text, Text, Text>{
		private Text outputKey = new Text();
		private Text outputValue = new Text();
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String []array = value.toString().trim().split("\t");
			String userId = array[0];
			if(array.length==2) {
				outputValue.set(array[1]);
				String[] friends = array[1].split(",");
				for (String data : friends) {
					int user = Integer.parseInt(userId);
					int friend = Integer.parseInt(data);
					if(user< friend) 
						outputKey.set(user+","+friend);
					else
						outputKey.set(friend+","+user);
					context.write(outputKey, outputValue);
					
				}
			}
		}
	}
	
	public static class MutualReduce extends Reducer<Text, Text, Text, Text>{
		private Text outputKey = new Text();
		//private IntWritable outputValue = new IntWritable();
		private Text outputValue1 = new Text();
		private Map<String, Integer> countMap = new HashMap<>();
		private Map<String, String> map2 = new HashMap<>();
		private int counter =0;
		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			//ArrayList<String> friendLists = new ArrayList<>();
			String friendLists = "";
			Text []friendArr = new Text[2];
			int i=0;
			Iterator<Text> iterator = values.iterator();
			while(iterator.hasNext()) {
				friendArr[i] = new Text();
				friendArr[i].set(iterator.next());
				i++;
			}
			String user1Friends[] = friendArr[0].toString().split(",");
			String user2Friends[] = friendArr[1].toString().split(",");
			int length1 = user1Friends.length;
			int length2 = user2Friends.length;
			for(int j=0;j<length1;j++) {
				for(int k=0;k<length2;k++) {
					if(user1Friends[j].equals(user2Friends[k])) {
						//friendLists.add(user1Friends[j]);
						friendLists+=user1Friends[j]+",";
					}
				}
			}
			int len = friendLists.length();
			countMap.put(key.toString(), len);
			map2.put(key.toString(),friendLists);
//			context.write(outputKey,outputValue);
		}
		
		@Override
		protected void cleanup(Reducer<Text, Text, Text, Text>.Context context)
				throws IOException, InterruptedException {
			List<Map.Entry<String, Integer>> mapToList = new LinkedList<Map.Entry<String, Integer>>( countMap.entrySet() );
	        Collections.sort( mapToList, new Comparator<Map.Entry<String, Integer>>() {
	            public int compare( Map.Entry<String, Integer> count1, Map.Entry<String, Integer> count2 )
	            {
	                return (count2.getValue()).compareTo( count1.getValue() );
	            }
	        } );
	       // Map <String, Integer> finalCountMap = new HashMap<>();
	        for(Map.Entry<String, Integer> entry : mapToList) {
	        	//finalCountMap.put(entry.getKey(), entry.getValue());
				String str;
				outputKey.set(entry.getKey());
				String a = map2.get(entry.getKey());
				str = Integer.toString(entry.getValue())+"	"+a;
				outputValue1.set(str);
				
	        	if(counter==10)
	        		break;
	        	context.write(outputKey,outputValue1);
	        	counter++;
	        }
			super.cleanup(context);
		}
	}
	
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub

		Configuration conf = new Configuration();
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		// get all args
		if (otherArgs.length != 2) {
			System.err.println("Usage: MutualFriends <in> <out>");
			System.exit(2);
		}
		
		conf.set("ARGUMENT",otherArgs[1]);

		// create a job with name "wordcount"
		@SuppressWarnings("deprecation")
		Job job = new Job(conf, "mutualfriends");
		job.setJarByClass(Top10MutualFriends.class);
		job.setMapperClass(MutualMap.class);
		job.setReducerClass(MutualReduce.class);


		// uncomment the following line to add the Combiner job.setCombinerClass(Reduce.class);


		
		job.setOutputKeyClass(Text.class);
		// set output value type
		job.setOutputValueClass(Text.class);
		//set the HDFS path of the input data
		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		// set the HDFS path for the output
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
		//Wait till job completion
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}