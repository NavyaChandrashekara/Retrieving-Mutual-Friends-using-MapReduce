import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
@SuppressWarnings("unused")
public class MutualFriends {

	public static class MutualMap extends Mapper<LongWritable, Text, Text, Text>{
		private Text outputKey = new Text();
		private Text outputValue = new Text();
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String []array = value.toString().trim().split("\t");
			String userId = array[0];
			if(array.length==2) {
				outputValue.set(array[1]);
				String[] friends = array[1].split(",");
				for (String data : friends) {
					int user = Integer.parseInt(userId);
					int friend = Integer.parseInt(data);
					if(user< friend) 
						outputKey.set(user+","+friend);
					else
						outputKey.set(friend+","+user);
					context.write(outputKey, outputValue);
					
				}
			}
		}
	}
	
	public static class MutualReduce extends Reducer<Text, Text, Text, Text>{
		private Text outputKey = new Text();
		private Text outputValue = new Text();
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			String friendLists = "";
			Text []friendArr = new Text[2];
			int i=0;
			Iterator<Text> iterator = values.iterator();
			//System.out.print(key.toString()+"  :  ");
			while(iterator.hasNext()) {
				friendArr[i] = new Text();
				friendArr[i].set(iterator.next());
				i++;
			}
			String user1Friends[] = friendArr[0].toString().split(",");
			String user2Friends[] = friendArr[1].toString().split(",");
			int length1 = user1Friends.length;
			int length2 = user2Friends.length;
			int count = 0;
			String[] key_array = key.toString().split(",");
			int k1 = Integer.parseInt(key_array[0]);
			int k2 = Integer.parseInt(key_array[1]);
			if((k1==0 && k2==1) || (k1==20 && k2==28193) || (k1==1 && k2==29826) || (k1==6222 && k2==19272) || (k1==28041 && k2==28056)){
							
				for(int j=0;j<length1;j++) {
					for(int k=0;k<length2;k++) {
						if(user1Friends[j].equals(user2Friends[k])) {
							friendLists+=user1Friends[j]+",";
							count++;
						}
					}
				}
				int len = friendLists.length();
				outputKey = key;
				if(count==0)
					outputValue.set("");
				else
					outputValue.set(friendLists);
				context.write(outputKey,outputValue);
			}
		}
	}
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		// TODO Auto-generated method stub

		Configuration conf = new Configuration();
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		// get all args
		if (otherArgs.length != 2) {
			System.err.println("Usage: MutualFriends <in> <out>");
			System.exit(2);
		}
		
		conf.set("ARGUMENT",otherArgs[1]);

		// create a job with name "wordcount"
		@SuppressWarnings("deprecation")
		Job job = new Job(conf, "mutualfriends");
		job.setJarByClass(MutualFriends.class);
		job.setMapperClass(MutualMap.class);
		job.setReducerClass(MutualReduce.class);


		// uncomment the following line to add the Combiner job.setCombinerClass(Reduce.class);


		
		job.setOutputKeyClass(Text.class);
		// set output value type
		job.setOutputValueClass(Text.class);
		//set the HDFS path of the input data
		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		// set the HDFS path for the output
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
		//Wait till job completion
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}